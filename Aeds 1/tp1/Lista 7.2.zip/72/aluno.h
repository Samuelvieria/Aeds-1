#ifndef aluno_h
#define aluno_h
#include <iostream>
#include <string>
#include "pessoa.h"


class aluno :  pessoa {
  
}